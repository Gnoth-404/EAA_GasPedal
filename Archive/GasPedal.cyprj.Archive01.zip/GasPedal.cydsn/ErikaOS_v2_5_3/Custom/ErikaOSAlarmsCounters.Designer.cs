namespace ErikaOS_v2_5_3
{
    partial class ErikaOSAlarmsCounters
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_RemoveCounter = new System.Windows.Forms.Button();
            this.button_AddCounter = new System.Windows.Forms.Button();
            this.tabControl_Counters = new System.Windows.Forms.TabControl();
            this.tabPage_Counter1 = new System.Windows.Forms.TabPage();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.Counter_1_Max = new System.Windows.Forms.NumericUpDown();
            this.Counter_1_Min = new System.Windows.Forms.NumericUpDown();
            this.Counter_1_Tick = new System.Windows.Forms.NumericUpDown();
            this.label41 = new System.Windows.Forms.Label();
            this.Counter_1_Name = new System.Windows.Forms.TextBox();
            this.tabPage_Counter2 = new System.Windows.Forms.TabPage();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.Counter_2_Max = new System.Windows.Forms.NumericUpDown();
            this.Counter_2_Min = new System.Windows.Forms.NumericUpDown();
            this.Counter_2_Tick = new System.Windows.Forms.NumericUpDown();
            this.label48 = new System.Windows.Forms.Label();
            this.Counter_2_Name = new System.Windows.Forms.TextBox();
            this.tabPage_Counter3 = new System.Windows.Forms.TabPage();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.Counter_3_Max = new System.Windows.Forms.NumericUpDown();
            this.Counter_3_Min = new System.Windows.Forms.NumericUpDown();
            this.Counter_3_Tick = new System.Windows.Forms.NumericUpDown();
            this.label52 = new System.Windows.Forms.Label();
            this.Counter_3_Name = new System.Windows.Forms.TextBox();
            this.tabPage_Counter4 = new System.Windows.Forms.TabPage();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.Counter_4_Max = new System.Windows.Forms.NumericUpDown();
            this.Counter_4_Min = new System.Windows.Forms.NumericUpDown();
            this.Counter_4_Tick = new System.Windows.Forms.NumericUpDown();
            this.label56 = new System.Windows.Forms.Label();
            this.Counter_4_Name = new System.Windows.Forms.TextBox();
            this.button_RemoveAlarm = new System.Windows.Forms.Button();
            this.button_AddAlarm = new System.Windows.Forms.Button();
            this.tabControl_Alarms = new System.Windows.Forms.TabControl();
            this.tabPage_Alarm1 = new System.Windows.Forms.TabPage();
            this.label57 = new System.Windows.Forms.Label();
            this.Alarm_1_Task = new System.Windows.Forms.ComboBox();
            this.Alarm_1_Callback = new System.Windows.Forms.TextBox();
            this.Alarm_1_Name = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Alarm_1_Event = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Alarm_1_Counter = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Alarm_1_Action = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage_Alarm2 = new System.Windows.Forms.TabPage();
            this.label58 = new System.Windows.Forms.Label();
            this.Alarm_2_Task = new System.Windows.Forms.ComboBox();
            this.Alarm_2_Callback = new System.Windows.Forms.TextBox();
            this.Alarm_2_Name = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Alarm_2_Event = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Alarm_2_Counter = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Alarm_2_Action = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPage_Alarm3 = new System.Windows.Forms.TabPage();
            this.label59 = new System.Windows.Forms.Label();
            this.Alarm_3_Task = new System.Windows.Forms.ComboBox();
            this.Alarm_3_Callback = new System.Windows.Forms.TextBox();
            this.Alarm_3_Name = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Alarm_3_Event = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.Alarm_3_Counter = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.Alarm_3_Action = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tabPage_Alarm4 = new System.Windows.Forms.TabPage();
            this.label60 = new System.Windows.Forms.Label();
            this.Alarm_4_Task = new System.Windows.Forms.ComboBox();
            this.Alarm_4_Callback = new System.Windows.Forms.TextBox();
            this.Alarm_4_Name = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.Alarm_4_Event = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.Alarm_4_Counter = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.Alarm_4_Action = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tabPage_Alarm5 = new System.Windows.Forms.TabPage();
            this.label61 = new System.Windows.Forms.Label();
            this.Alarm_5_Task = new System.Windows.Forms.ComboBox();
            this.Alarm_5_Callback = new System.Windows.Forms.TextBox();
            this.Alarm_5_Name = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.Alarm_5_Event = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.Alarm_5_Counter = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.Alarm_5_Action = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.tabPage_Alarm6 = new System.Windows.Forms.TabPage();
            this.label62 = new System.Windows.Forms.Label();
            this.Alarm_6_Task = new System.Windows.Forms.ComboBox();
            this.Alarm_6_Callback = new System.Windows.Forms.TextBox();
            this.Alarm_6_Name = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.Alarm_6_Event = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.Alarm_6_Counter = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.Alarm_6_Action = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.tabPage_Alarm7 = new System.Windows.Forms.TabPage();
            this.label63 = new System.Windows.Forms.Label();
            this.Alarm_7_Task = new System.Windows.Forms.ComboBox();
            this.Alarm_7_Callback = new System.Windows.Forms.TextBox();
            this.Alarm_7_Name = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.Alarm_7_Event = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.Alarm_7_Counter = new System.Windows.Forms.ComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.Alarm_7_Action = new System.Windows.Forms.ComboBox();
            this.label35 = new System.Windows.Forms.Label();
            this.tabPage_Alarm8 = new System.Windows.Forms.TabPage();
            this.label64 = new System.Windows.Forms.Label();
            this.Alarm_8_Task = new System.Windows.Forms.ComboBox();
            this.Alarm_8_Callback = new System.Windows.Forms.TextBox();
            this.Alarm_8_Name = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.Alarm_8_Event = new System.Windows.Forms.ComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.Alarm_8_Counter = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.Alarm_8_Action = new System.Windows.Forms.ComboBox();
            this.label40 = new System.Windows.Forms.Label();
            this.tabControl_Counters.SuspendLayout();
            this.tabPage_Counter1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_1_Max)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_1_Min)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_1_Tick)).BeginInit();
            this.tabPage_Counter2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_2_Max)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_2_Min)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_2_Tick)).BeginInit();
            this.tabPage_Counter3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_3_Max)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_3_Min)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_3_Tick)).BeginInit();
            this.tabPage_Counter4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_4_Max)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_4_Min)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_4_Tick)).BeginInit();
            this.tabControl_Alarms.SuspendLayout();
            this.tabPage_Alarm1.SuspendLayout();
            this.tabPage_Alarm2.SuspendLayout();
            this.tabPage_Alarm3.SuspendLayout();
            this.tabPage_Alarm4.SuspendLayout();
            this.tabPage_Alarm5.SuspendLayout();
            this.tabPage_Alarm6.SuspendLayout();
            this.tabPage_Alarm7.SuspendLayout();
            this.tabPage_Alarm8.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_RemoveCounter
            // 
            this.button_RemoveCounter.Location = new System.Drawing.Point(152, 222);
            this.button_RemoveCounter.Name = "button_RemoveCounter";
            this.button_RemoveCounter.Size = new System.Drawing.Size(56, 25);
            this.button_RemoveCounter.TabIndex = 17;
            this.button_RemoveCounter.Text = "Remove";
            this.button_RemoveCounter.UseVisualStyleBackColor = true;
            this.button_RemoveCounter.Click += new System.EventHandler(this.button_RemoveCounter_Click);
            // 
            // button_AddCounter
            // 
            this.button_AddCounter.Location = new System.Drawing.Point(90, 222);
            this.button_AddCounter.Name = "button_AddCounter";
            this.button_AddCounter.Size = new System.Drawing.Size(56, 25);
            this.button_AddCounter.TabIndex = 16;
            this.button_AddCounter.Text = "Add";
            this.button_AddCounter.UseVisualStyleBackColor = true;
            this.button_AddCounter.Click += new System.EventHandler(this.button_AddCounter_Click);
            // 
            // tabControl_Counters
            // 
            this.tabControl_Counters.Controls.Add(this.tabPage_Counter1);
            this.tabControl_Counters.Controls.Add(this.tabPage_Counter2);
            this.tabControl_Counters.Controls.Add(this.tabPage_Counter3);
            this.tabControl_Counters.Controls.Add(this.tabPage_Counter4);
            this.tabControl_Counters.Location = new System.Drawing.Point(8, 7);
            this.tabControl_Counters.Name = "tabControl_Counters";
            this.tabControl_Counters.SelectedIndex = 0;
            this.tabControl_Counters.Size = new System.Drawing.Size(200, 213);
            this.tabControl_Counters.TabIndex = 15;
            // 
            // tabPage_Counter1
            // 
            this.tabPage_Counter1.Controls.Add(this.label44);
            this.tabPage_Counter1.Controls.Add(this.label43);
            this.tabPage_Counter1.Controls.Add(this.label42);
            this.tabPage_Counter1.Controls.Add(this.Counter_1_Max);
            this.tabPage_Counter1.Controls.Add(this.Counter_1_Min);
            this.tabPage_Counter1.Controls.Add(this.Counter_1_Tick);
            this.tabPage_Counter1.Controls.Add(this.label41);
            this.tabPage_Counter1.Controls.Add(this.Counter_1_Name);
            this.tabPage_Counter1.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Counter1.Name = "tabPage_Counter1";
            this.tabPage_Counter1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Counter1.Size = new System.Drawing.Size(192, 187);
            this.tabPage_Counter1.TabIndex = 0;
            this.tabPage_Counter1.Text = "Counter_1";
            this.tabPage_Counter1.UseVisualStyleBackColor = true;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(3, 78);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(53, 13);
            this.label44.TabIndex = 15;
            this.label44.Text = "Min Cycle";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(6, 117);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(57, 13);
            this.label43.TabIndex = 14;
            this.label43.Text = "Max Value";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(3, 39);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(68, 13);
            this.label42.TabIndex = 13;
            this.label42.Text = "Counter Tick";
            // 
            // Counter_1_Max
            // 
            this.Counter_1_Max.Location = new System.Drawing.Point(3, 133);
            this.Counter_1_Max.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.Counter_1_Max.Name = "Counter_1_Max";
            this.Counter_1_Max.Size = new System.Drawing.Size(120, 20);
            this.Counter_1_Max.TabIndex = 12;
            this.Counter_1_Max.ValueChanged += new System.EventHandler(this.Counter_1_Max_ValueChanged);
            // 
            // Counter_1_Min
            // 
            this.Counter_1_Min.Location = new System.Drawing.Point(3, 94);
            this.Counter_1_Min.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.Counter_1_Min.Name = "Counter_1_Min";
            this.Counter_1_Min.Size = new System.Drawing.Size(120, 20);
            this.Counter_1_Min.TabIndex = 11;
            this.Counter_1_Min.ValueChanged += new System.EventHandler(this.Counter_1_Min_ValueChanged);
            // 
            // Counter_1_Tick
            // 
            this.Counter_1_Tick.Location = new System.Drawing.Point(3, 55);
            this.Counter_1_Tick.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.Counter_1_Tick.Name = "Counter_1_Tick";
            this.Counter_1_Tick.Size = new System.Drawing.Size(120, 20);
            this.Counter_1_Tick.TabIndex = 10;
            this.Counter_1_Tick.ValueChanged += new System.EventHandler(this.Counter_1_Tick_ValueChanged);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(3, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(75, 13);
            this.label41.TabIndex = 9;
            this.label41.Text = "Counter Name";
            // 
            // Counter_1_Name
            // 
            this.Counter_1_Name.Location = new System.Drawing.Point(3, 16);
            this.Counter_1_Name.Name = "Counter_1_Name";
            this.Counter_1_Name.Size = new System.Drawing.Size(108, 20);
            this.Counter_1_Name.TabIndex = 8;
            this.Counter_1_Name.TextChanged += new System.EventHandler(this.Counter_1_Name_TextChanged);
            // 
            // tabPage_Counter2
            // 
            this.tabPage_Counter2.Controls.Add(this.label45);
            this.tabPage_Counter2.Controls.Add(this.label46);
            this.tabPage_Counter2.Controls.Add(this.label47);
            this.tabPage_Counter2.Controls.Add(this.Counter_2_Max);
            this.tabPage_Counter2.Controls.Add(this.Counter_2_Min);
            this.tabPage_Counter2.Controls.Add(this.Counter_2_Tick);
            this.tabPage_Counter2.Controls.Add(this.label48);
            this.tabPage_Counter2.Controls.Add(this.Counter_2_Name);
            this.tabPage_Counter2.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Counter2.Name = "tabPage_Counter2";
            this.tabPage_Counter2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Counter2.Size = new System.Drawing.Size(192, 187);
            this.tabPage_Counter2.TabIndex = 1;
            this.tabPage_Counter2.Text = "Counter_2";
            this.tabPage_Counter2.UseVisualStyleBackColor = true;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(3, 78);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(53, 13);
            this.label45.TabIndex = 23;
            this.label45.Text = "Min Cycle";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(6, 117);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(57, 13);
            this.label46.TabIndex = 22;
            this.label46.Text = "Max Value";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(3, 39);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(68, 13);
            this.label47.TabIndex = 21;
            this.label47.Text = "Counter Tick";
            // 
            // Counter_2_Max
            // 
            this.Counter_2_Max.Location = new System.Drawing.Point(3, 133);
            this.Counter_2_Max.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.Counter_2_Max.Name = "Counter_2_Max";
            this.Counter_2_Max.Size = new System.Drawing.Size(120, 20);
            this.Counter_2_Max.TabIndex = 20;
            this.Counter_2_Max.ValueChanged += new System.EventHandler(this.Counter_2_Max_ValueChanged);
            // 
            // Counter_2_Min
            // 
            this.Counter_2_Min.Location = new System.Drawing.Point(3, 94);
            this.Counter_2_Min.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.Counter_2_Min.Name = "Counter_2_Min";
            this.Counter_2_Min.Size = new System.Drawing.Size(120, 20);
            this.Counter_2_Min.TabIndex = 19;
            this.Counter_2_Min.ValueChanged += new System.EventHandler(this.Counter_2_Min_ValueChanged);
            // 
            // Counter_2_Tick
            // 
            this.Counter_2_Tick.Location = new System.Drawing.Point(3, 55);
            this.Counter_2_Tick.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.Counter_2_Tick.Name = "Counter_2_Tick";
            this.Counter_2_Tick.Size = new System.Drawing.Size(120, 20);
            this.Counter_2_Tick.TabIndex = 18;
            this.Counter_2_Tick.ValueChanged += new System.EventHandler(this.Counter_2_Tick_ValueChanged);
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(3, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(75, 13);
            this.label48.TabIndex = 17;
            this.label48.Text = "Counter Name";
            // 
            // Counter_2_Name
            // 
            this.Counter_2_Name.Location = new System.Drawing.Point(3, 16);
            this.Counter_2_Name.Name = "Counter_2_Name";
            this.Counter_2_Name.Size = new System.Drawing.Size(108, 20);
            this.Counter_2_Name.TabIndex = 16;
            this.Counter_2_Name.TextChanged += new System.EventHandler(this.Counter_2_Name_TextChanged);
            // 
            // tabPage_Counter3
            // 
            this.tabPage_Counter3.Controls.Add(this.label49);
            this.tabPage_Counter3.Controls.Add(this.label50);
            this.tabPage_Counter3.Controls.Add(this.label51);
            this.tabPage_Counter3.Controls.Add(this.Counter_3_Max);
            this.tabPage_Counter3.Controls.Add(this.Counter_3_Min);
            this.tabPage_Counter3.Controls.Add(this.Counter_3_Tick);
            this.tabPage_Counter3.Controls.Add(this.label52);
            this.tabPage_Counter3.Controls.Add(this.Counter_3_Name);
            this.tabPage_Counter3.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Counter3.Name = "tabPage_Counter3";
            this.tabPage_Counter3.Size = new System.Drawing.Size(192, 187);
            this.tabPage_Counter3.TabIndex = 2;
            this.tabPage_Counter3.Text = "Counter_3";
            this.tabPage_Counter3.UseVisualStyleBackColor = true;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(3, 79);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(53, 13);
            this.label49.TabIndex = 23;
            this.label49.Text = "Min Cycle";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(6, 118);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(57, 13);
            this.label50.TabIndex = 22;
            this.label50.Text = "Max Value";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(3, 40);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(68, 13);
            this.label51.TabIndex = 21;
            this.label51.Text = "Counter Tick";
            // 
            // Counter_3_Max
            // 
            this.Counter_3_Max.Location = new System.Drawing.Point(3, 134);
            this.Counter_3_Max.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.Counter_3_Max.Name = "Counter_3_Max";
            this.Counter_3_Max.Size = new System.Drawing.Size(120, 20);
            this.Counter_3_Max.TabIndex = 20;
            this.Counter_3_Max.ValueChanged += new System.EventHandler(this.Counter_3_Max_ValueChanged);
            // 
            // Counter_3_Min
            // 
            this.Counter_3_Min.Location = new System.Drawing.Point(3, 95);
            this.Counter_3_Min.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.Counter_3_Min.Name = "Counter_3_Min";
            this.Counter_3_Min.Size = new System.Drawing.Size(120, 20);
            this.Counter_3_Min.TabIndex = 19;
            this.Counter_3_Min.ValueChanged += new System.EventHandler(this.Counter_3_Min_ValueChanged);
            // 
            // Counter_3_Tick
            // 
            this.Counter_3_Tick.Location = new System.Drawing.Point(3, 56);
            this.Counter_3_Tick.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.Counter_3_Tick.Name = "Counter_3_Tick";
            this.Counter_3_Tick.Size = new System.Drawing.Size(120, 20);
            this.Counter_3_Tick.TabIndex = 18;
            this.Counter_3_Tick.ValueChanged += new System.EventHandler(this.Counter_3_Tick_ValueChanged);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(3, 1);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(75, 13);
            this.label52.TabIndex = 17;
            this.label52.Text = "Counter Name";
            // 
            // Counter_3_Name
            // 
            this.Counter_3_Name.Location = new System.Drawing.Point(3, 17);
            this.Counter_3_Name.Name = "Counter_3_Name";
            this.Counter_3_Name.Size = new System.Drawing.Size(108, 20);
            this.Counter_3_Name.TabIndex = 16;
            this.Counter_3_Name.TextChanged += new System.EventHandler(this.Counter_3_Name_TextChanged);
            // 
            // tabPage_Counter4
            // 
            this.tabPage_Counter4.Controls.Add(this.label53);
            this.tabPage_Counter4.Controls.Add(this.label54);
            this.tabPage_Counter4.Controls.Add(this.label55);
            this.tabPage_Counter4.Controls.Add(this.Counter_4_Max);
            this.tabPage_Counter4.Controls.Add(this.Counter_4_Min);
            this.tabPage_Counter4.Controls.Add(this.Counter_4_Tick);
            this.tabPage_Counter4.Controls.Add(this.label56);
            this.tabPage_Counter4.Controls.Add(this.Counter_4_Name);
            this.tabPage_Counter4.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Counter4.Name = "tabPage_Counter4";
            this.tabPage_Counter4.Size = new System.Drawing.Size(192, 187);
            this.tabPage_Counter4.TabIndex = 3;
            this.tabPage_Counter4.Text = "Counter_4";
            this.tabPage_Counter4.UseVisualStyleBackColor = true;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(3, 79);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(53, 13);
            this.label53.TabIndex = 23;
            this.label53.Text = "Min Cycle";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(6, 118);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(57, 13);
            this.label54.TabIndex = 22;
            this.label54.Text = "Max Value";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(3, 40);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(68, 13);
            this.label55.TabIndex = 21;
            this.label55.Text = "Counter Tick";
            // 
            // Counter_4_Max
            // 
            this.Counter_4_Max.Location = new System.Drawing.Point(3, 134);
            this.Counter_4_Max.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.Counter_4_Max.Name = "Counter_4_Max";
            this.Counter_4_Max.Size = new System.Drawing.Size(120, 20);
            this.Counter_4_Max.TabIndex = 20;
            this.Counter_4_Max.ValueChanged += new System.EventHandler(this.Counter_4_Max_ValueChanged);
            // 
            // Counter_4_Min
            // 
            this.Counter_4_Min.Location = new System.Drawing.Point(3, 95);
            this.Counter_4_Min.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.Counter_4_Min.Name = "Counter_4_Min";
            this.Counter_4_Min.Size = new System.Drawing.Size(120, 20);
            this.Counter_4_Min.TabIndex = 19;
            this.Counter_4_Min.ValueChanged += new System.EventHandler(this.Counter_4_Min_ValueChanged);
            // 
            // Counter_4_Tick
            // 
            this.Counter_4_Tick.Location = new System.Drawing.Point(3, 56);
            this.Counter_4_Tick.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.Counter_4_Tick.Name = "Counter_4_Tick";
            this.Counter_4_Tick.Size = new System.Drawing.Size(120, 20);
            this.Counter_4_Tick.TabIndex = 18;
            this.Counter_4_Tick.ValueChanged += new System.EventHandler(this.Counter_4_Tick_ValueChanged);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(3, 1);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(75, 13);
            this.label56.TabIndex = 17;
            this.label56.Text = "Counter Name";
            // 
            // Counter_4_Name
            // 
            this.Counter_4_Name.Location = new System.Drawing.Point(3, 17);
            this.Counter_4_Name.Name = "Counter_4_Name";
            this.Counter_4_Name.Size = new System.Drawing.Size(108, 20);
            this.Counter_4_Name.TabIndex = 16;
            this.Counter_4_Name.TextChanged += new System.EventHandler(this.Counter_4_Name_TextChanged);
            // 
            // button_RemoveAlarm
            // 
            this.button_RemoveAlarm.Location = new System.Drawing.Point(398, 222);
            this.button_RemoveAlarm.Name = "button_RemoveAlarm";
            this.button_RemoveAlarm.Size = new System.Drawing.Size(56, 25);
            this.button_RemoveAlarm.TabIndex = 14;
            this.button_RemoveAlarm.Text = "Remove";
            this.button_RemoveAlarm.UseVisualStyleBackColor = true;
            this.button_RemoveAlarm.Click += new System.EventHandler(this.button_RemoveAlarm_Click);
            // 
            // button_AddAlarm
            // 
            this.button_AddAlarm.Location = new System.Drawing.Point(336, 222);
            this.button_AddAlarm.Name = "button_AddAlarm";
            this.button_AddAlarm.Size = new System.Drawing.Size(56, 25);
            this.button_AddAlarm.TabIndex = 13;
            this.button_AddAlarm.Text = "Add";
            this.button_AddAlarm.UseVisualStyleBackColor = true;
            this.button_AddAlarm.Click += new System.EventHandler(this.button_AddAlarm_Click);
            // 
            // tabControl_Alarms
            // 
            this.tabControl_Alarms.Controls.Add(this.tabPage_Alarm1);
            this.tabControl_Alarms.Controls.Add(this.tabPage_Alarm2);
            this.tabControl_Alarms.Controls.Add(this.tabPage_Alarm3);
            this.tabControl_Alarms.Controls.Add(this.tabPage_Alarm4);
            this.tabControl_Alarms.Controls.Add(this.tabPage_Alarm5);
            this.tabControl_Alarms.Controls.Add(this.tabPage_Alarm6);
            this.tabControl_Alarms.Controls.Add(this.tabPage_Alarm7);
            this.tabControl_Alarms.Controls.Add(this.tabPage_Alarm8);
            this.tabControl_Alarms.Location = new System.Drawing.Point(218, 7);
            this.tabControl_Alarms.Name = "tabControl_Alarms";
            this.tabControl_Alarms.SelectedIndex = 0;
            this.tabControl_Alarms.Size = new System.Drawing.Size(236, 213);
            this.tabControl_Alarms.TabIndex = 12;
            // 
            // tabPage_Alarm1
            // 
            this.tabPage_Alarm1.Controls.Add(this.label57);
            this.tabPage_Alarm1.Controls.Add(this.Alarm_1_Task);
            this.tabPage_Alarm1.Controls.Add(this.Alarm_1_Callback);
            this.tabPage_Alarm1.Controls.Add(this.Alarm_1_Name);
            this.tabPage_Alarm1.Controls.Add(this.label5);
            this.tabPage_Alarm1.Controls.Add(this.Alarm_1_Event);
            this.tabPage_Alarm1.Controls.Add(this.label4);
            this.tabPage_Alarm1.Controls.Add(this.Alarm_1_Counter);
            this.tabPage_Alarm1.Controls.Add(this.label3);
            this.tabPage_Alarm1.Controls.Add(this.label2);
            this.tabPage_Alarm1.Controls.Add(this.Alarm_1_Action);
            this.tabPage_Alarm1.Controls.Add(this.label1);
            this.tabPage_Alarm1.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Alarm1.Name = "tabPage_Alarm1";
            this.tabPage_Alarm1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Alarm1.Size = new System.Drawing.Size(228, 187);
            this.tabPage_Alarm1.TabIndex = 0;
            this.tabPage_Alarm1.Text = "Alarm_1";
            this.tabPage_Alarm1.UseVisualStyleBackColor = true;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(117, 39);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(31, 13);
            this.label57.TabIndex = 17;
            this.label57.Text = "Task";
            // 
            // Alarm_1_Task
            // 
            this.Alarm_1_Task.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_1_Task.FormattingEnabled = true;
            this.Alarm_1_Task.Location = new System.Drawing.Point(117, 55);
            this.Alarm_1_Task.Name = "Alarm_1_Task";
            this.Alarm_1_Task.Size = new System.Drawing.Size(108, 21);
            this.Alarm_1_Task.TabIndex = 16;
            this.Alarm_1_Task.SelectedIndexChanged += new System.EventHandler(this.Alarm_1_Task_SelectedIndexChanged);
            // 
            // Alarm_1_Callback
            // 
            this.Alarm_1_Callback.Location = new System.Drawing.Point(117, 16);
            this.Alarm_1_Callback.Name = "Alarm_1_Callback";
            this.Alarm_1_Callback.Size = new System.Drawing.Size(108, 20);
            this.Alarm_1_Callback.TabIndex = 15;
            this.Alarm_1_Callback.TextChanged += new System.EventHandler(this.Alarm_1_Callback_TextChanged);
            // 
            // Alarm_1_Name
            // 
            this.Alarm_1_Name.Location = new System.Drawing.Point(3, 16);
            this.Alarm_1_Name.Name = "Alarm_1_Name";
            this.Alarm_1_Name.Size = new System.Drawing.Size(108, 20);
            this.Alarm_1_Name.TabIndex = 4;
            this.Alarm_1_Name.TextChanged += new System.EventHandler(this.Alarm_1_Name_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(117, 1);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Callback Name";
            // 
            // Alarm_1_Event
            // 
            this.Alarm_1_Event.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_1_Event.FormattingEnabled = true;
            this.Alarm_1_Event.Items.AddRange(new object[] {
            "Event"});
            this.Alarm_1_Event.Location = new System.Drawing.Point(3, 135);
            this.Alarm_1_Event.Name = "Alarm_1_Event";
            this.Alarm_1_Event.Size = new System.Drawing.Size(108, 21);
            this.Alarm_1_Event.TabIndex = 13;
            this.Alarm_1_Event.SelectedIndexChanged += new System.EventHandler(this.Alarm_1_Event_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Event";
            // 
            // Alarm_1_Counter
            // 
            this.Alarm_1_Counter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_1_Counter.FormattingEnabled = true;
            this.Alarm_1_Counter.Items.AddRange(new object[] {
            "Counter"});
            this.Alarm_1_Counter.Location = new System.Drawing.Point(3, 55);
            this.Alarm_1_Counter.Name = "Alarm_1_Counter";
            this.Alarm_1_Counter.Size = new System.Drawing.Size(108, 21);
            this.Alarm_1_Counter.TabIndex = 11;
            this.Alarm_1_Counter.SelectedIndexChanged += new System.EventHandler(this.Alarm_1_Counter_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Counter";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Alarm Action";
            // 
            // Alarm_1_Action
            // 
            this.Alarm_1_Action.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_1_Action.FormattingEnabled = true;
            this.Alarm_1_Action.Items.AddRange(new object[] {
            "Activate Task",
            "Set Event",
            "Callback"});
            this.Alarm_1_Action.Location = new System.Drawing.Point(3, 95);
            this.Alarm_1_Action.Name = "Alarm_1_Action";
            this.Alarm_1_Action.Size = new System.Drawing.Size(108, 21);
            this.Alarm_1_Action.TabIndex = 8;
            this.Alarm_1_Action.SelectedIndexChanged += new System.EventHandler(this.Alarm_1_Action_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Alarm Name";
            // 
            // tabPage_Alarm2
            // 
            this.tabPage_Alarm2.Controls.Add(this.label58);
            this.tabPage_Alarm2.Controls.Add(this.Alarm_2_Task);
            this.tabPage_Alarm2.Controls.Add(this.Alarm_2_Callback);
            this.tabPage_Alarm2.Controls.Add(this.Alarm_2_Name);
            this.tabPage_Alarm2.Controls.Add(this.label6);
            this.tabPage_Alarm2.Controls.Add(this.Alarm_2_Event);
            this.tabPage_Alarm2.Controls.Add(this.label7);
            this.tabPage_Alarm2.Controls.Add(this.Alarm_2_Counter);
            this.tabPage_Alarm2.Controls.Add(this.label8);
            this.tabPage_Alarm2.Controls.Add(this.label9);
            this.tabPage_Alarm2.Controls.Add(this.Alarm_2_Action);
            this.tabPage_Alarm2.Controls.Add(this.label10);
            this.tabPage_Alarm2.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Alarm2.Name = "tabPage_Alarm2";
            this.tabPage_Alarm2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Alarm2.Size = new System.Drawing.Size(228, 187);
            this.tabPage_Alarm2.TabIndex = 1;
            this.tabPage_Alarm2.Text = "Alarm_2";
            this.tabPage_Alarm2.UseVisualStyleBackColor = true;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(117, 39);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(31, 13);
            this.label58.TabIndex = 27;
            this.label58.Text = "Task";
            // 
            // Alarm_2_Task
            // 
            this.Alarm_2_Task.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_2_Task.FormattingEnabled = true;
            this.Alarm_2_Task.Items.AddRange(new object[] {
            "Counter"});
            this.Alarm_2_Task.Location = new System.Drawing.Point(117, 55);
            this.Alarm_2_Task.Name = "Alarm_2_Task";
            this.Alarm_2_Task.Size = new System.Drawing.Size(108, 21);
            this.Alarm_2_Task.TabIndex = 26;
            this.Alarm_2_Task.SelectedIndexChanged += new System.EventHandler(this.Alarm_2_Task_SelectedIndexChanged);
            // 
            // Alarm_2_Callback
            // 
            this.Alarm_2_Callback.Location = new System.Drawing.Point(117, 16);
            this.Alarm_2_Callback.Name = "Alarm_2_Callback";
            this.Alarm_2_Callback.Size = new System.Drawing.Size(108, 20);
            this.Alarm_2_Callback.TabIndex = 25;
            this.Alarm_2_Callback.TextChanged += new System.EventHandler(this.Alarm_2_Callback_TextChanged);
            // 
            // Alarm_2_Name
            // 
            this.Alarm_2_Name.Location = new System.Drawing.Point(3, 16);
            this.Alarm_2_Name.Name = "Alarm_2_Name";
            this.Alarm_2_Name.Size = new System.Drawing.Size(108, 20);
            this.Alarm_2_Name.TabIndex = 16;
            this.Alarm_2_Name.TextChanged += new System.EventHandler(this.Alarm_2_Name_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(117, 1);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 13);
            this.label6.TabIndex = 24;
            this.label6.Text = "Callback Name";
            // 
            // Alarm_2_Event
            // 
            this.Alarm_2_Event.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_2_Event.FormattingEnabled = true;
            this.Alarm_2_Event.Items.AddRange(new object[] {
            "Event"});
            this.Alarm_2_Event.Location = new System.Drawing.Point(3, 135);
            this.Alarm_2_Event.Name = "Alarm_2_Event";
            this.Alarm_2_Event.Size = new System.Drawing.Size(108, 21);
            this.Alarm_2_Event.TabIndex = 23;
            this.Alarm_2_Event.SelectedIndexChanged += new System.EventHandler(this.Alarm_2_Event_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 119);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 22;
            this.label7.Text = "Event";
            // 
            // Alarm_2_Counter
            // 
            this.Alarm_2_Counter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_2_Counter.FormattingEnabled = true;
            this.Alarm_2_Counter.Items.AddRange(new object[] {
            "Counter"});
            this.Alarm_2_Counter.Location = new System.Drawing.Point(3, 55);
            this.Alarm_2_Counter.Name = "Alarm_2_Counter";
            this.Alarm_2_Counter.Size = new System.Drawing.Size(108, 21);
            this.Alarm_2_Counter.TabIndex = 21;
            this.Alarm_2_Counter.SelectedIndexChanged += new System.EventHandler(this.Alarm_2_Counter_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 39);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "Counter";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 79);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "Alarm Action";
            // 
            // Alarm_2_Action
            // 
            this.Alarm_2_Action.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_2_Action.FormattingEnabled = true;
            this.Alarm_2_Action.Items.AddRange(new object[] {
            "Activate Task",
            "Set Event",
            "Callback"});
            this.Alarm_2_Action.Location = new System.Drawing.Point(3, 95);
            this.Alarm_2_Action.Name = "Alarm_2_Action";
            this.Alarm_2_Action.Size = new System.Drawing.Size(108, 21);
            this.Alarm_2_Action.TabIndex = 18;
            this.Alarm_2_Action.SelectedIndexChanged += new System.EventHandler(this.Alarm_2_Action_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "Alarm Name";
            // 
            // tabPage_Alarm3
            // 
            this.tabPage_Alarm3.Controls.Add(this.label59);
            this.tabPage_Alarm3.Controls.Add(this.Alarm_3_Task);
            this.tabPage_Alarm3.Controls.Add(this.Alarm_3_Callback);
            this.tabPage_Alarm3.Controls.Add(this.Alarm_3_Name);
            this.tabPage_Alarm3.Controls.Add(this.label11);
            this.tabPage_Alarm3.Controls.Add(this.Alarm_3_Event);
            this.tabPage_Alarm3.Controls.Add(this.label12);
            this.tabPage_Alarm3.Controls.Add(this.Alarm_3_Counter);
            this.tabPage_Alarm3.Controls.Add(this.label13);
            this.tabPage_Alarm3.Controls.Add(this.label14);
            this.tabPage_Alarm3.Controls.Add(this.Alarm_3_Action);
            this.tabPage_Alarm3.Controls.Add(this.label15);
            this.tabPage_Alarm3.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Alarm3.Name = "tabPage_Alarm3";
            this.tabPage_Alarm3.Size = new System.Drawing.Size(228, 187);
            this.tabPage_Alarm3.TabIndex = 2;
            this.tabPage_Alarm3.Text = "Alarm_3";
            this.tabPage_Alarm3.UseVisualStyleBackColor = true;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(117, 39);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(31, 13);
            this.label59.TabIndex = 27;
            this.label59.Text = "Task";
            // 
            // Alarm_3_Task
            // 
            this.Alarm_3_Task.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_3_Task.FormattingEnabled = true;
            this.Alarm_3_Task.Items.AddRange(new object[] {
            "Counter"});
            this.Alarm_3_Task.Location = new System.Drawing.Point(117, 55);
            this.Alarm_3_Task.Name = "Alarm_3_Task";
            this.Alarm_3_Task.Size = new System.Drawing.Size(108, 21);
            this.Alarm_3_Task.TabIndex = 26;
            this.Alarm_3_Task.SelectedIndexChanged += new System.EventHandler(this.Alarm_3_Task_SelectedIndexChanged);
            // 
            // Alarm_3_Callback
            // 
            this.Alarm_3_Callback.Location = new System.Drawing.Point(117, 16);
            this.Alarm_3_Callback.Name = "Alarm_3_Callback";
            this.Alarm_3_Callback.Size = new System.Drawing.Size(108, 20);
            this.Alarm_3_Callback.TabIndex = 25;
            this.Alarm_3_Callback.TextChanged += new System.EventHandler(this.Alarm_3_Callback_TextChanged);
            // 
            // Alarm_3_Name
            // 
            this.Alarm_3_Name.Location = new System.Drawing.Point(3, 16);
            this.Alarm_3_Name.Name = "Alarm_3_Name";
            this.Alarm_3_Name.Size = new System.Drawing.Size(108, 20);
            this.Alarm_3_Name.TabIndex = 16;
            this.Alarm_3_Name.TextChanged += new System.EventHandler(this.Alarm_3_Name_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(117, 1);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(79, 13);
            this.label11.TabIndex = 24;
            this.label11.Text = "Callback Name";
            // 
            // Alarm_3_Event
            // 
            this.Alarm_3_Event.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_3_Event.FormattingEnabled = true;
            this.Alarm_3_Event.Items.AddRange(new object[] {
            "Event"});
            this.Alarm_3_Event.Location = new System.Drawing.Point(3, 135);
            this.Alarm_3_Event.Name = "Alarm_3_Event";
            this.Alarm_3_Event.Size = new System.Drawing.Size(108, 21);
            this.Alarm_3_Event.TabIndex = 23;
            this.Alarm_3_Event.SelectedIndexChanged += new System.EventHandler(this.Alarm_3_Event_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 119);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 13);
            this.label12.TabIndex = 22;
            this.label12.Text = "Event";
            // 
            // Alarm_3_Counter
            // 
            this.Alarm_3_Counter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_3_Counter.FormattingEnabled = true;
            this.Alarm_3_Counter.Items.AddRange(new object[] {
            "Counter"});
            this.Alarm_3_Counter.Location = new System.Drawing.Point(3, 55);
            this.Alarm_3_Counter.Name = "Alarm_3_Counter";
            this.Alarm_3_Counter.Size = new System.Drawing.Size(108, 21);
            this.Alarm_3_Counter.TabIndex = 21;
            this.Alarm_3_Counter.SelectedIndexChanged += new System.EventHandler(this.Alarm_3_Counter_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 39);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 13);
            this.label13.TabIndex = 20;
            this.label13.Text = "Counter";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 79);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(66, 13);
            this.label14.TabIndex = 19;
            this.label14.Text = "Alarm Action";
            // 
            // Alarm_3_Action
            // 
            this.Alarm_3_Action.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_3_Action.FormattingEnabled = true;
            this.Alarm_3_Action.Items.AddRange(new object[] {
            "Activate Task",
            "Set Event",
            "Callback"});
            this.Alarm_3_Action.Location = new System.Drawing.Point(3, 95);
            this.Alarm_3_Action.Name = "Alarm_3_Action";
            this.Alarm_3_Action.Size = new System.Drawing.Size(108, 21);
            this.Alarm_3_Action.TabIndex = 18;
            this.Alarm_3_Action.SelectedIndexChanged += new System.EventHandler(this.Alarm_3_Action_SelectedIndexChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(64, 13);
            this.label15.TabIndex = 17;
            this.label15.Text = "Alarm Name";
            // 
            // tabPage_Alarm4
            // 
            this.tabPage_Alarm4.Controls.Add(this.label60);
            this.tabPage_Alarm4.Controls.Add(this.Alarm_4_Task);
            this.tabPage_Alarm4.Controls.Add(this.Alarm_4_Callback);
            this.tabPage_Alarm4.Controls.Add(this.Alarm_4_Name);
            this.tabPage_Alarm4.Controls.Add(this.label16);
            this.tabPage_Alarm4.Controls.Add(this.Alarm_4_Event);
            this.tabPage_Alarm4.Controls.Add(this.label17);
            this.tabPage_Alarm4.Controls.Add(this.Alarm_4_Counter);
            this.tabPage_Alarm4.Controls.Add(this.label18);
            this.tabPage_Alarm4.Controls.Add(this.label19);
            this.tabPage_Alarm4.Controls.Add(this.Alarm_4_Action);
            this.tabPage_Alarm4.Controls.Add(this.label20);
            this.tabPage_Alarm4.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Alarm4.Name = "tabPage_Alarm4";
            this.tabPage_Alarm4.Size = new System.Drawing.Size(228, 187);
            this.tabPage_Alarm4.TabIndex = 3;
            this.tabPage_Alarm4.Text = "Alarm_4";
            this.tabPage_Alarm4.UseVisualStyleBackColor = true;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(117, 39);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(31, 13);
            this.label60.TabIndex = 27;
            this.label60.Text = "Task";
            // 
            // Alarm_4_Task
            // 
            this.Alarm_4_Task.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_4_Task.FormattingEnabled = true;
            this.Alarm_4_Task.Items.AddRange(new object[] {
            "Counter"});
            this.Alarm_4_Task.Location = new System.Drawing.Point(117, 55);
            this.Alarm_4_Task.Name = "Alarm_4_Task";
            this.Alarm_4_Task.Size = new System.Drawing.Size(108, 21);
            this.Alarm_4_Task.TabIndex = 26;
            this.Alarm_4_Task.SelectedIndexChanged += new System.EventHandler(this.Alarm_4_Task_SelectedIndexChanged);
            // 
            // Alarm_4_Callback
            // 
            this.Alarm_4_Callback.Location = new System.Drawing.Point(117, 16);
            this.Alarm_4_Callback.Name = "Alarm_4_Callback";
            this.Alarm_4_Callback.Size = new System.Drawing.Size(108, 20);
            this.Alarm_4_Callback.TabIndex = 25;
            this.Alarm_4_Callback.TextChanged += new System.EventHandler(this.Alarm_4_Callback_TextChanged);
            // 
            // Alarm_4_Name
            // 
            this.Alarm_4_Name.Location = new System.Drawing.Point(3, 16);
            this.Alarm_4_Name.Name = "Alarm_4_Name";
            this.Alarm_4_Name.Size = new System.Drawing.Size(108, 20);
            this.Alarm_4_Name.TabIndex = 16;
            this.Alarm_4_Name.TextChanged += new System.EventHandler(this.Alarm_4_Name_TextChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(117, 1);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(79, 13);
            this.label16.TabIndex = 24;
            this.label16.Text = "Callback Name";
            // 
            // Alarm_4_Event
            // 
            this.Alarm_4_Event.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_4_Event.FormattingEnabled = true;
            this.Alarm_4_Event.Items.AddRange(new object[] {
            "Event"});
            this.Alarm_4_Event.Location = new System.Drawing.Point(3, 135);
            this.Alarm_4_Event.Name = "Alarm_4_Event";
            this.Alarm_4_Event.Size = new System.Drawing.Size(108, 21);
            this.Alarm_4_Event.TabIndex = 23;
            this.Alarm_4_Event.SelectedIndexChanged += new System.EventHandler(this.Alarm_4_Event_SelectedIndexChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(3, 119);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 13);
            this.label17.TabIndex = 22;
            this.label17.Text = "Event";
            // 
            // Alarm_4_Counter
            // 
            this.Alarm_4_Counter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_4_Counter.FormattingEnabled = true;
            this.Alarm_4_Counter.Items.AddRange(new object[] {
            "Counter"});
            this.Alarm_4_Counter.Location = new System.Drawing.Point(3, 55);
            this.Alarm_4_Counter.Name = "Alarm_4_Counter";
            this.Alarm_4_Counter.Size = new System.Drawing.Size(108, 21);
            this.Alarm_4_Counter.TabIndex = 21;
            this.Alarm_4_Counter.SelectedIndexChanged += new System.EventHandler(this.Alarm_4_Counter_SelectedIndexChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(3, 39);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(44, 13);
            this.label18.TabIndex = 20;
            this.label18.Text = "Counter";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(3, 79);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(66, 13);
            this.label19.TabIndex = 19;
            this.label19.Text = "Alarm Action";
            // 
            // Alarm_4_Action
            // 
            this.Alarm_4_Action.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_4_Action.FormattingEnabled = true;
            this.Alarm_4_Action.Items.AddRange(new object[] {
            "Activate Task",
            "Set Event",
            "Callback"});
            this.Alarm_4_Action.Location = new System.Drawing.Point(3, 95);
            this.Alarm_4_Action.Name = "Alarm_4_Action";
            this.Alarm_4_Action.Size = new System.Drawing.Size(108, 21);
            this.Alarm_4_Action.TabIndex = 18;
            this.Alarm_4_Action.SelectedIndexChanged += new System.EventHandler(this.Alarm_4_Action_SelectedIndexChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(3, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(64, 13);
            this.label20.TabIndex = 17;
            this.label20.Text = "Alarm Name";
            // 
            // tabPage_Alarm5
            // 
            this.tabPage_Alarm5.Controls.Add(this.label61);
            this.tabPage_Alarm5.Controls.Add(this.Alarm_5_Task);
            this.tabPage_Alarm5.Controls.Add(this.Alarm_5_Callback);
            this.tabPage_Alarm5.Controls.Add(this.Alarm_5_Name);
            this.tabPage_Alarm5.Controls.Add(this.label21);
            this.tabPage_Alarm5.Controls.Add(this.Alarm_5_Event);
            this.tabPage_Alarm5.Controls.Add(this.label22);
            this.tabPage_Alarm5.Controls.Add(this.Alarm_5_Counter);
            this.tabPage_Alarm5.Controls.Add(this.label23);
            this.tabPage_Alarm5.Controls.Add(this.label24);
            this.tabPage_Alarm5.Controls.Add(this.Alarm_5_Action);
            this.tabPage_Alarm5.Controls.Add(this.label25);
            this.tabPage_Alarm5.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Alarm5.Name = "tabPage_Alarm5";
            this.tabPage_Alarm5.Size = new System.Drawing.Size(228, 187);
            this.tabPage_Alarm5.TabIndex = 4;
            this.tabPage_Alarm5.Text = "Alarm_5";
            this.tabPage_Alarm5.UseVisualStyleBackColor = true;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(117, 39);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(31, 13);
            this.label61.TabIndex = 27;
            this.label61.Text = "Task";
            // 
            // Alarm_5_Task
            // 
            this.Alarm_5_Task.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_5_Task.FormattingEnabled = true;
            this.Alarm_5_Task.Items.AddRange(new object[] {
            "Counter"});
            this.Alarm_5_Task.Location = new System.Drawing.Point(117, 55);
            this.Alarm_5_Task.Name = "Alarm_5_Task";
            this.Alarm_5_Task.Size = new System.Drawing.Size(108, 21);
            this.Alarm_5_Task.TabIndex = 26;
            this.Alarm_5_Task.SelectedIndexChanged += new System.EventHandler(this.Alarm_5_Task_SelectedIndexChanged);
            // 
            // Alarm_5_Callback
            // 
            this.Alarm_5_Callback.Location = new System.Drawing.Point(117, 16);
            this.Alarm_5_Callback.Name = "Alarm_5_Callback";
            this.Alarm_5_Callback.Size = new System.Drawing.Size(108, 20);
            this.Alarm_5_Callback.TabIndex = 25;
            this.Alarm_5_Callback.TextChanged += new System.EventHandler(this.Alarm_5_Callback_TextChanged);
            // 
            // Alarm_5_Name
            // 
            this.Alarm_5_Name.Location = new System.Drawing.Point(3, 16);
            this.Alarm_5_Name.Name = "Alarm_5_Name";
            this.Alarm_5_Name.Size = new System.Drawing.Size(108, 20);
            this.Alarm_5_Name.TabIndex = 16;
            this.Alarm_5_Name.TextChanged += new System.EventHandler(this.Alarm_5_Name_TextChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(117, 1);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(79, 13);
            this.label21.TabIndex = 24;
            this.label21.Text = "Callback Name";
            // 
            // Alarm_5_Event
            // 
            this.Alarm_5_Event.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_5_Event.FormattingEnabled = true;
            this.Alarm_5_Event.Items.AddRange(new object[] {
            "Event"});
            this.Alarm_5_Event.Location = new System.Drawing.Point(3, 135);
            this.Alarm_5_Event.Name = "Alarm_5_Event";
            this.Alarm_5_Event.Size = new System.Drawing.Size(108, 21);
            this.Alarm_5_Event.TabIndex = 23;
            this.Alarm_5_Event.SelectedIndexChanged += new System.EventHandler(this.Alarm_5_Event_SelectedIndexChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(3, 119);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(35, 13);
            this.label22.TabIndex = 22;
            this.label22.Text = "Event";
            // 
            // Alarm_5_Counter
            // 
            this.Alarm_5_Counter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_5_Counter.FormattingEnabled = true;
            this.Alarm_5_Counter.Items.AddRange(new object[] {
            "Counter"});
            this.Alarm_5_Counter.Location = new System.Drawing.Point(3, 55);
            this.Alarm_5_Counter.Name = "Alarm_5_Counter";
            this.Alarm_5_Counter.Size = new System.Drawing.Size(108, 21);
            this.Alarm_5_Counter.TabIndex = 21;
            this.Alarm_5_Counter.SelectedIndexChanged += new System.EventHandler(this.Alarm_5_Counter_SelectedIndexChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(3, 39);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(44, 13);
            this.label23.TabIndex = 20;
            this.label23.Text = "Counter";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(3, 79);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(66, 13);
            this.label24.TabIndex = 19;
            this.label24.Text = "Alarm Action";
            // 
            // Alarm_5_Action
            // 
            this.Alarm_5_Action.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_5_Action.FormattingEnabled = true;
            this.Alarm_5_Action.Items.AddRange(new object[] {
            "Activate Task",
            "Set Event",
            "Callback"});
            this.Alarm_5_Action.Location = new System.Drawing.Point(3, 95);
            this.Alarm_5_Action.Name = "Alarm_5_Action";
            this.Alarm_5_Action.Size = new System.Drawing.Size(108, 21);
            this.Alarm_5_Action.TabIndex = 18;
            this.Alarm_5_Action.SelectedIndexChanged += new System.EventHandler(this.Alarm_5_Action_SelectedIndexChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(3, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(64, 13);
            this.label25.TabIndex = 17;
            this.label25.Text = "Alarm Name";
            // 
            // tabPage_Alarm6
            // 
            this.tabPage_Alarm6.Controls.Add(this.label62);
            this.tabPage_Alarm6.Controls.Add(this.Alarm_6_Task);
            this.tabPage_Alarm6.Controls.Add(this.Alarm_6_Callback);
            this.tabPage_Alarm6.Controls.Add(this.Alarm_6_Name);
            this.tabPage_Alarm6.Controls.Add(this.label26);
            this.tabPage_Alarm6.Controls.Add(this.Alarm_6_Event);
            this.tabPage_Alarm6.Controls.Add(this.label27);
            this.tabPage_Alarm6.Controls.Add(this.Alarm_6_Counter);
            this.tabPage_Alarm6.Controls.Add(this.label28);
            this.tabPage_Alarm6.Controls.Add(this.label29);
            this.tabPage_Alarm6.Controls.Add(this.Alarm_6_Action);
            this.tabPage_Alarm6.Controls.Add(this.label30);
            this.tabPage_Alarm6.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Alarm6.Name = "tabPage_Alarm6";
            this.tabPage_Alarm6.Size = new System.Drawing.Size(228, 187);
            this.tabPage_Alarm6.TabIndex = 5;
            this.tabPage_Alarm6.Text = "Alarm_6";
            this.tabPage_Alarm6.UseVisualStyleBackColor = true;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(117, 39);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(31, 13);
            this.label62.TabIndex = 27;
            this.label62.Text = "Task";
            // 
            // Alarm_6_Task
            // 
            this.Alarm_6_Task.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_6_Task.FormattingEnabled = true;
            this.Alarm_6_Task.Items.AddRange(new object[] {
            "Counter"});
            this.Alarm_6_Task.Location = new System.Drawing.Point(117, 55);
            this.Alarm_6_Task.Name = "Alarm_6_Task";
            this.Alarm_6_Task.Size = new System.Drawing.Size(108, 21);
            this.Alarm_6_Task.TabIndex = 26;
            this.Alarm_6_Task.SelectedIndexChanged += new System.EventHandler(this.Alarm_6_Task_SelectedIndexChanged);
            // 
            // Alarm_6_Callback
            // 
            this.Alarm_6_Callback.Location = new System.Drawing.Point(117, 16);
            this.Alarm_6_Callback.Name = "Alarm_6_Callback";
            this.Alarm_6_Callback.Size = new System.Drawing.Size(108, 20);
            this.Alarm_6_Callback.TabIndex = 25;
            this.Alarm_6_Callback.TextChanged += new System.EventHandler(this.Alarm_6_Callback_TextChanged);
            // 
            // Alarm_6_Name
            // 
            this.Alarm_6_Name.Location = new System.Drawing.Point(3, 16);
            this.Alarm_6_Name.Name = "Alarm_6_Name";
            this.Alarm_6_Name.Size = new System.Drawing.Size(108, 20);
            this.Alarm_6_Name.TabIndex = 16;
            this.Alarm_6_Name.TextChanged += new System.EventHandler(this.Alarm_6_Name_TextChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(117, 1);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(79, 13);
            this.label26.TabIndex = 24;
            this.label26.Text = "Callback Name";
            // 
            // Alarm_6_Event
            // 
            this.Alarm_6_Event.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_6_Event.FormattingEnabled = true;
            this.Alarm_6_Event.Items.AddRange(new object[] {
            "Event"});
            this.Alarm_6_Event.Location = new System.Drawing.Point(3, 135);
            this.Alarm_6_Event.Name = "Alarm_6_Event";
            this.Alarm_6_Event.Size = new System.Drawing.Size(108, 21);
            this.Alarm_6_Event.TabIndex = 23;
            this.Alarm_6_Event.SelectedIndexChanged += new System.EventHandler(this.Alarm_6_Event_SelectedIndexChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(3, 119);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(35, 13);
            this.label27.TabIndex = 22;
            this.label27.Text = "Event";
            // 
            // Alarm_6_Counter
            // 
            this.Alarm_6_Counter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_6_Counter.FormattingEnabled = true;
            this.Alarm_6_Counter.Items.AddRange(new object[] {
            "Counter"});
            this.Alarm_6_Counter.Location = new System.Drawing.Point(3, 55);
            this.Alarm_6_Counter.Name = "Alarm_6_Counter";
            this.Alarm_6_Counter.Size = new System.Drawing.Size(108, 21);
            this.Alarm_6_Counter.TabIndex = 21;
            this.Alarm_6_Counter.SelectedIndexChanged += new System.EventHandler(this.Alarm_6_Counter_SelectedIndexChanged);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(3, 39);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(44, 13);
            this.label28.TabIndex = 20;
            this.label28.Text = "Counter";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(3, 79);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(66, 13);
            this.label29.TabIndex = 19;
            this.label29.Text = "Alarm Action";
            // 
            // Alarm_6_Action
            // 
            this.Alarm_6_Action.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_6_Action.FormattingEnabled = true;
            this.Alarm_6_Action.Items.AddRange(new object[] {
            "Activate Task",
            "Set Event",
            "Callback"});
            this.Alarm_6_Action.Location = new System.Drawing.Point(3, 95);
            this.Alarm_6_Action.Name = "Alarm_6_Action";
            this.Alarm_6_Action.Size = new System.Drawing.Size(108, 21);
            this.Alarm_6_Action.TabIndex = 18;
            this.Alarm_6_Action.SelectedIndexChanged += new System.EventHandler(this.Alarm_6_Action_SelectedIndexChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(3, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(64, 13);
            this.label30.TabIndex = 17;
            this.label30.Text = "Alarm Name";
            // 
            // tabPage_Alarm7
            // 
            this.tabPage_Alarm7.Controls.Add(this.label63);
            this.tabPage_Alarm7.Controls.Add(this.Alarm_7_Task);
            this.tabPage_Alarm7.Controls.Add(this.Alarm_7_Callback);
            this.tabPage_Alarm7.Controls.Add(this.Alarm_7_Name);
            this.tabPage_Alarm7.Controls.Add(this.label31);
            this.tabPage_Alarm7.Controls.Add(this.Alarm_7_Event);
            this.tabPage_Alarm7.Controls.Add(this.label32);
            this.tabPage_Alarm7.Controls.Add(this.Alarm_7_Counter);
            this.tabPage_Alarm7.Controls.Add(this.label33);
            this.tabPage_Alarm7.Controls.Add(this.label34);
            this.tabPage_Alarm7.Controls.Add(this.Alarm_7_Action);
            this.tabPage_Alarm7.Controls.Add(this.label35);
            this.tabPage_Alarm7.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Alarm7.Name = "tabPage_Alarm7";
            this.tabPage_Alarm7.Size = new System.Drawing.Size(228, 187);
            this.tabPage_Alarm7.TabIndex = 6;
            this.tabPage_Alarm7.Text = "Alarm_7";
            this.tabPage_Alarm7.UseVisualStyleBackColor = true;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(117, 39);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(31, 13);
            this.label63.TabIndex = 27;
            this.label63.Text = "Task";
            // 
            // Alarm_7_Task
            // 
            this.Alarm_7_Task.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_7_Task.FormattingEnabled = true;
            this.Alarm_7_Task.Items.AddRange(new object[] {
            "Counter"});
            this.Alarm_7_Task.Location = new System.Drawing.Point(117, 55);
            this.Alarm_7_Task.Name = "Alarm_7_Task";
            this.Alarm_7_Task.Size = new System.Drawing.Size(108, 21);
            this.Alarm_7_Task.TabIndex = 26;
            this.Alarm_7_Task.SelectedIndexChanged += new System.EventHandler(this.Alarm_7_Task_SelectedIndexChanged);
            // 
            // Alarm_7_Callback
            // 
            this.Alarm_7_Callback.Location = new System.Drawing.Point(117, 16);
            this.Alarm_7_Callback.Name = "Alarm_7_Callback";
            this.Alarm_7_Callback.Size = new System.Drawing.Size(108, 20);
            this.Alarm_7_Callback.TabIndex = 25;
            this.Alarm_7_Callback.TextChanged += new System.EventHandler(this.Alarm_7_Callback_TextChanged);
            // 
            // Alarm_7_Name
            // 
            this.Alarm_7_Name.Location = new System.Drawing.Point(3, 16);
            this.Alarm_7_Name.Name = "Alarm_7_Name";
            this.Alarm_7_Name.Size = new System.Drawing.Size(108, 20);
            this.Alarm_7_Name.TabIndex = 16;
            this.Alarm_7_Name.TextChanged += new System.EventHandler(this.Alarm_7_Name_TextChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(117, 1);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(79, 13);
            this.label31.TabIndex = 24;
            this.label31.Text = "Callback Name";
            // 
            // Alarm_7_Event
            // 
            this.Alarm_7_Event.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_7_Event.FormattingEnabled = true;
            this.Alarm_7_Event.Items.AddRange(new object[] {
            "Event"});
            this.Alarm_7_Event.Location = new System.Drawing.Point(3, 135);
            this.Alarm_7_Event.Name = "Alarm_7_Event";
            this.Alarm_7_Event.Size = new System.Drawing.Size(108, 21);
            this.Alarm_7_Event.TabIndex = 23;
            this.Alarm_7_Event.SelectedIndexChanged += new System.EventHandler(this.Alarm_7_Event_SelectedIndexChanged);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(3, 119);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(35, 13);
            this.label32.TabIndex = 22;
            this.label32.Text = "Event";
            // 
            // Alarm_7_Counter
            // 
            this.Alarm_7_Counter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_7_Counter.FormattingEnabled = true;
            this.Alarm_7_Counter.Items.AddRange(new object[] {
            "Counter"});
            this.Alarm_7_Counter.Location = new System.Drawing.Point(3, 55);
            this.Alarm_7_Counter.Name = "Alarm_7_Counter";
            this.Alarm_7_Counter.Size = new System.Drawing.Size(108, 21);
            this.Alarm_7_Counter.TabIndex = 21;
            this.Alarm_7_Counter.SelectedIndexChanged += new System.EventHandler(this.Alarm_7_Counter_SelectedIndexChanged);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(3, 39);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(44, 13);
            this.label33.TabIndex = 20;
            this.label33.Text = "Counter";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(3, 79);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(66, 13);
            this.label34.TabIndex = 19;
            this.label34.Text = "Alarm Action";
            // 
            // Alarm_7_Action
            // 
            this.Alarm_7_Action.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_7_Action.FormattingEnabled = true;
            this.Alarm_7_Action.Items.AddRange(new object[] {
            "Activate Task",
            "Set Event",
            "Callback"});
            this.Alarm_7_Action.Location = new System.Drawing.Point(3, 95);
            this.Alarm_7_Action.Name = "Alarm_7_Action";
            this.Alarm_7_Action.Size = new System.Drawing.Size(108, 21);
            this.Alarm_7_Action.TabIndex = 18;
            this.Alarm_7_Action.SelectedIndexChanged += new System.EventHandler(this.Alarm_7_Action_SelectedIndexChanged);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(3, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(64, 13);
            this.label35.TabIndex = 17;
            this.label35.Text = "Alarm Name";
            // 
            // tabPage_Alarm8
            // 
            this.tabPage_Alarm8.Controls.Add(this.label64);
            this.tabPage_Alarm8.Controls.Add(this.Alarm_8_Task);
            this.tabPage_Alarm8.Controls.Add(this.Alarm_8_Callback);
            this.tabPage_Alarm8.Controls.Add(this.Alarm_8_Name);
            this.tabPage_Alarm8.Controls.Add(this.label36);
            this.tabPage_Alarm8.Controls.Add(this.Alarm_8_Event);
            this.tabPage_Alarm8.Controls.Add(this.label37);
            this.tabPage_Alarm8.Controls.Add(this.Alarm_8_Counter);
            this.tabPage_Alarm8.Controls.Add(this.label38);
            this.tabPage_Alarm8.Controls.Add(this.label39);
            this.tabPage_Alarm8.Controls.Add(this.Alarm_8_Action);
            this.tabPage_Alarm8.Controls.Add(this.label40);
            this.tabPage_Alarm8.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Alarm8.Name = "tabPage_Alarm8";
            this.tabPage_Alarm8.Size = new System.Drawing.Size(228, 187);
            this.tabPage_Alarm8.TabIndex = 7;
            this.tabPage_Alarm8.Text = "Alarm_8";
            this.tabPage_Alarm8.UseVisualStyleBackColor = true;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(117, 39);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(31, 13);
            this.label64.TabIndex = 27;
            this.label64.Text = "Task";
            // 
            // Alarm_8_Task
            // 
            this.Alarm_8_Task.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_8_Task.FormattingEnabled = true;
            this.Alarm_8_Task.Items.AddRange(new object[] {
            "Counter"});
            this.Alarm_8_Task.Location = new System.Drawing.Point(117, 55);
            this.Alarm_8_Task.Name = "Alarm_8_Task";
            this.Alarm_8_Task.Size = new System.Drawing.Size(108, 21);
            this.Alarm_8_Task.TabIndex = 26;
            this.Alarm_8_Task.SelectedIndexChanged += new System.EventHandler(this.Alarm_8_Task_SelectedIndexChanged);
            // 
            // Alarm_8_Callback
            // 
            this.Alarm_8_Callback.Location = new System.Drawing.Point(117, 16);
            this.Alarm_8_Callback.Name = "Alarm_8_Callback";
            this.Alarm_8_Callback.Size = new System.Drawing.Size(108, 20);
            this.Alarm_8_Callback.TabIndex = 25;
            this.Alarm_8_Callback.TextChanged += new System.EventHandler(this.Alarm_8_Callback_TextChanged);
            // 
            // Alarm_8_Name
            // 
            this.Alarm_8_Name.Location = new System.Drawing.Point(3, 16);
            this.Alarm_8_Name.Name = "Alarm_8_Name";
            this.Alarm_8_Name.Size = new System.Drawing.Size(108, 20);
            this.Alarm_8_Name.TabIndex = 16;
            this.Alarm_8_Name.TextChanged += new System.EventHandler(this.Alarm_8_Name_TextChanged);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(117, 1);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(79, 13);
            this.label36.TabIndex = 24;
            this.label36.Text = "Callback Name";
            // 
            // Alarm_8_Event
            // 
            this.Alarm_8_Event.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_8_Event.FormattingEnabled = true;
            this.Alarm_8_Event.Items.AddRange(new object[] {
            "Event"});
            this.Alarm_8_Event.Location = new System.Drawing.Point(3, 135);
            this.Alarm_8_Event.Name = "Alarm_8_Event";
            this.Alarm_8_Event.Size = new System.Drawing.Size(108, 21);
            this.Alarm_8_Event.TabIndex = 23;
            this.Alarm_8_Event.SelectedIndexChanged += new System.EventHandler(this.Alarm_8_Event_SelectedIndexChanged);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(3, 119);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(35, 13);
            this.label37.TabIndex = 22;
            this.label37.Text = "Event";
            // 
            // Alarm_8_Counter
            // 
            this.Alarm_8_Counter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_8_Counter.FormattingEnabled = true;
            this.Alarm_8_Counter.Items.AddRange(new object[] {
            "Counter"});
            this.Alarm_8_Counter.Location = new System.Drawing.Point(3, 55);
            this.Alarm_8_Counter.Name = "Alarm_8_Counter";
            this.Alarm_8_Counter.Size = new System.Drawing.Size(108, 21);
            this.Alarm_8_Counter.TabIndex = 21;
            this.Alarm_8_Counter.SelectedIndexChanged += new System.EventHandler(this.Alarm_8_Counter_SelectedIndexChanged);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(3, 39);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(44, 13);
            this.label38.TabIndex = 20;
            this.label38.Text = "Counter";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(3, 79);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(66, 13);
            this.label39.TabIndex = 19;
            this.label39.Text = "Alarm Action";
            // 
            // Alarm_8_Action
            // 
            this.Alarm_8_Action.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Alarm_8_Action.FormattingEnabled = true;
            this.Alarm_8_Action.Items.AddRange(new object[] {
            "Activate Task",
            "Set Event",
            "Callback"});
            this.Alarm_8_Action.Location = new System.Drawing.Point(3, 95);
            this.Alarm_8_Action.Name = "Alarm_8_Action";
            this.Alarm_8_Action.Size = new System.Drawing.Size(108, 21);
            this.Alarm_8_Action.TabIndex = 18;
            this.Alarm_8_Action.SelectedIndexChanged += new System.EventHandler(this.Alarm_8_Action_SelectedIndexChanged);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(3, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(64, 13);
            this.label40.TabIndex = 17;
            this.label40.Text = "Alarm Name";
            // 
            // ErikaOSAlarmsCounters
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.Controls.Add(this.button_RemoveCounter);
            this.Controls.Add(this.button_AddCounter);
            this.Controls.Add(this.tabControl_Counters);
            this.Controls.Add(this.button_RemoveAlarm);
            this.Controls.Add(this.button_AddAlarm);
            this.Controls.Add(this.tabControl_Alarms);
            this.Name = "ErikaOSAlarmsCounters";
            this.Size = new System.Drawing.Size(462, 254);
            this.tabControl_Counters.ResumeLayout(false);
            this.tabPage_Counter1.ResumeLayout(false);
            this.tabPage_Counter1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_1_Max)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_1_Min)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_1_Tick)).EndInit();
            this.tabPage_Counter2.ResumeLayout(false);
            this.tabPage_Counter2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_2_Max)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_2_Min)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_2_Tick)).EndInit();
            this.tabPage_Counter3.ResumeLayout(false);
            this.tabPage_Counter3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_3_Max)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_3_Min)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_3_Tick)).EndInit();
            this.tabPage_Counter4.ResumeLayout(false);
            this.tabPage_Counter4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_4_Max)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_4_Min)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Counter_4_Tick)).EndInit();
            this.tabControl_Alarms.ResumeLayout(false);
            this.tabPage_Alarm1.ResumeLayout(false);
            this.tabPage_Alarm1.PerformLayout();
            this.tabPage_Alarm2.ResumeLayout(false);
            this.tabPage_Alarm2.PerformLayout();
            this.tabPage_Alarm3.ResumeLayout(false);
            this.tabPage_Alarm3.PerformLayout();
            this.tabPage_Alarm4.ResumeLayout(false);
            this.tabPage_Alarm4.PerformLayout();
            this.tabPage_Alarm5.ResumeLayout(false);
            this.tabPage_Alarm5.PerformLayout();
            this.tabPage_Alarm6.ResumeLayout(false);
            this.tabPage_Alarm6.PerformLayout();
            this.tabPage_Alarm7.ResumeLayout(false);
            this.tabPage_Alarm7.PerformLayout();
            this.tabPage_Alarm8.ResumeLayout(false);
            this.tabPage_Alarm8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_RemoveCounter;
        private System.Windows.Forms.Button button_AddCounter;
        private System.Windows.Forms.TabControl tabControl_Counters;
        private System.Windows.Forms.TabPage tabPage_Counter1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.NumericUpDown Counter_1_Max;
        private System.Windows.Forms.NumericUpDown Counter_1_Min;
        private System.Windows.Forms.NumericUpDown Counter_1_Tick;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox Counter_1_Name;
        private System.Windows.Forms.TabPage tabPage_Counter2;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.NumericUpDown Counter_2_Max;
        private System.Windows.Forms.NumericUpDown Counter_2_Min;
        private System.Windows.Forms.NumericUpDown Counter_2_Tick;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox Counter_2_Name;
        private System.Windows.Forms.TabPage tabPage_Counter3;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.NumericUpDown Counter_3_Max;
        private System.Windows.Forms.NumericUpDown Counter_3_Min;
        private System.Windows.Forms.NumericUpDown Counter_3_Tick;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox Counter_3_Name;
        private System.Windows.Forms.TabPage tabPage_Counter4;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.NumericUpDown Counter_4_Max;
        private System.Windows.Forms.NumericUpDown Counter_4_Min;
        private System.Windows.Forms.NumericUpDown Counter_4_Tick;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox Counter_4_Name;
        private System.Windows.Forms.Button button_RemoveAlarm;
        private System.Windows.Forms.Button button_AddAlarm;
        private System.Windows.Forms.TabControl tabControl_Alarms;
        private System.Windows.Forms.TabPage tabPage_Alarm1;
        private System.Windows.Forms.TextBox Alarm_1_Callback;
        private System.Windows.Forms.TextBox Alarm_1_Name;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox Alarm_1_Event;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox Alarm_1_Counter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox Alarm_1_Action;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage_Alarm2;
        private System.Windows.Forms.TextBox Alarm_2_Callback;
        private System.Windows.Forms.TextBox Alarm_2_Name;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox Alarm_2_Event;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox Alarm_2_Counter;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox Alarm_2_Action;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TabPage tabPage_Alarm3;
        private System.Windows.Forms.TextBox Alarm_3_Callback;
        private System.Windows.Forms.TextBox Alarm_3_Name;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox Alarm_3_Event;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox Alarm_3_Counter;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox Alarm_3_Action;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TabPage tabPage_Alarm4;
        private System.Windows.Forms.TextBox Alarm_4_Callback;
        private System.Windows.Forms.TextBox Alarm_4_Name;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox Alarm_4_Event;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox Alarm_4_Counter;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox Alarm_4_Action;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TabPage tabPage_Alarm5;
        private System.Windows.Forms.TextBox Alarm_5_Callback;
        private System.Windows.Forms.TextBox Alarm_5_Name;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox Alarm_5_Event;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox Alarm_5_Counter;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox Alarm_5_Action;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TabPage tabPage_Alarm6;
        private System.Windows.Forms.TextBox Alarm_6_Callback;
        private System.Windows.Forms.TextBox Alarm_6_Name;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox Alarm_6_Event;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox Alarm_6_Counter;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox Alarm_6_Action;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TabPage tabPage_Alarm7;
        private System.Windows.Forms.TextBox Alarm_7_Callback;
        private System.Windows.Forms.TextBox Alarm_7_Name;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox Alarm_7_Event;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ComboBox Alarm_7_Counter;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox Alarm_7_Action;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TabPage tabPage_Alarm8;
        private System.Windows.Forms.TextBox Alarm_8_Callback;
        private System.Windows.Forms.TextBox Alarm_8_Name;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox Alarm_8_Event;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox Alarm_8_Counter;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.ComboBox Alarm_8_Action;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.ComboBox Alarm_1_Task;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.ComboBox Alarm_2_Task;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.ComboBox Alarm_3_Task;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.ComboBox Alarm_4_Task;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.ComboBox Alarm_5_Task;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.ComboBox Alarm_6_Task;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.ComboBox Alarm_7_Task;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.ComboBox Alarm_8_Task;
    }
}
